
package appchallenge;

import forms.Principal;

/**
 *
 * @author guilherme.vcmoz
 */
public class AppChallenge {

    public static void main(String[] args) {
        Principal p = new Principal();
        p.setVisible(true);
       
    }
    
}
